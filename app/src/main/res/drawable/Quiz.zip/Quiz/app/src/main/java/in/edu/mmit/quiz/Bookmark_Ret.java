package in.edu.mmit.quiz;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;
import android.util.Log;

import com.readystatesoftware.sqliteasset.SQLiteAssetHelper;

import java.util.ArrayList;

public class Bookmark_Ret  extends SQLiteAssetHelper {
    private static final String Database_name = "DBase.db";//NAME of database stored in Assets folder
    private static final String Table_name = "question_bookmark";//name of table

    private static final int version = 1;//version of database signifies if there is any upgradation or not
    private Context context;//Context object to get context from Question Activity

    public Bookmark_Ret(Context context) {//constructor
        super(context, Database_name, context.getExternalFilesDir(null).getAbsolutePath(), null, version);
        this.context = context;
    }

    public void mark(Question_info x) {
        SQLiteDatabase db = getWritableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();
        String where = "QUESTION_ID = '"+x.Question_ID+"' ";
        if(check(x.Question_ID)==true) {
            Log.d( "mark: ",x.Que);

            ContentValues values = new ContentValues();
            values.put("QUESTION_ID", x.Question_ID);
            values.put("SUBJECT_ID", x.SUBJECT_ID);
            values.put("CHAPTER_ID", x.CHAPTER_ID);
            db.insert(Table_name, null, values);
        }
        else
        {
            Log.d( "mark: ",String.valueOf(x.Question_ID));

            db.delete(Table_name, where, null);
        }


    }
    public Boolean check(int x) {
        SQLiteDatabase db = getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();
        String where = "QUESTION_ID = '"+x+"' ";
        String [] sqlSelect = {"QUESTION_ID","SUBJECT_ID","CHAPTER_ID"};
        qb.setTables(Table_name);
        Cursor cursor = qb.query(db, sqlSelect, where, null,
                null, null, null);

        cursor.moveToFirst();
        if(cursor.getCount()==0) {
            return true;
        }
        else {
            Log.d( "mark+check: ",String.valueOf(x));

            return false;
        }

    }
    public ArrayList<Bookmark> getAll(int x){
        SQLiteDatabase db = getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();
        String [] sqlSelect = {"QUESTION_ID","SUBJECT_ID","CHAPTER_ID"};
        int i=0;
        qb.setTables(Table_name);
        Cursor cursor = qb.query(db, sqlSelect, null, null,
                null, null, null);
        cursor.moveToFirst();
        cursor.move(x);
        ArrayList<Bookmark> Bmarks = new ArrayList<>();
        if (cursor.moveToFirst()){
            Bmarks.add(new Bookmark(cursor.getInt(cursor.getColumnIndex("QUESTION_ID"))
                    ,cursor.getInt(cursor.getColumnIndex("SUBJECT_ID"))
                    ,cursor.getInt(cursor.getColumnIndex("CHAPTER_ID"))));
            while(cursor.moveToNext()&&i<30){
                Bmarks.add(new Bookmark(cursor.getInt(cursor.getColumnIndex("QUESTION_ID"))
                        ,cursor.getInt(cursor.getColumnIndex("SUBJECT_ID"))
                        ,cursor.getInt(cursor.getColumnIndex("CHAPTER_ID"))));   i++;   }
        }
    return Bmarks;
    }

}