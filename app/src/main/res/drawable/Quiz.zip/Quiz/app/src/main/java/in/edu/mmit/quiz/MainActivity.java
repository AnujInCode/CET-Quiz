package in.edu.mmit.quiz;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import com.google.android.material.textfield.TextInputEditText;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private final String Default = "N/A";
    Button  getStarted, Continue;
    EditText  edit_name, edit_email;
    TextInputEditText edit_password,edit_password2;
    TextView toast, name_display, forget;
    String[] Gender = {"Male", "Female"};
    String gender;
    ImageView icon_user;
    //Used to add some time so that user cannot directly press and exity out of the activity
    boolean doubleBackToExitPressedOnce = false;
    private ProgressDialog progressBar;//Create a circular progressBar Dialog

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Creating a shared preference file  to save the name ,mail address,password and also for setting the correct xml file
        final SharedPreferences sharedPreferences = getSharedPreferences("Content_main", Context.MODE_PRIVATE);//reference to shared preference file
        String name_file = sharedPreferences.getString("name", Default);
        String pass_file = sharedPreferences.getString("password", Default);
        String email_file = sharedPreferences.getString("email", Default);
        String gender_file = sharedPreferences.getString("gender", Default);
        SharedPreferences sp = getSharedPreferences("Score", Context.MODE_PRIVATE);

//        if (name_file.equals(Default) || pass_file.equals(Default) || email_file.equals(Default) || gender_file.equals(Default)) {
//
//            setContentView(R.layout.activity_main);
//
//
//        } else {

            Intent intent = new Intent(MainActivity.this, navigation_menu.class);
            startActivity(intent);
            finish();



//        }


    }

    public void onRadioButtonClicked(View view) {
        boolean checked = ((RadioButton) view).isChecked();

        switch(view.getId()) {
            case R.id.male:
                if (checked)
                   // icon_user.setImageResource(R.drawable.man);
                    gender=Gender[0];
                    break;
            case R.id.female:
                if (checked)
                 //   icon_user.setImageResource(R.drawable.female);
                    gender=Gender[1];
                    break;
        }
    }

    public void SignupActivity(View view) {
        setContentView(R.layout.activity_main);
        final SharedPreferences sharedPreferences = getSharedPreferences("Content_main", Context.MODE_PRIVATE);//reference to shared preference file

        edit_password = findViewById(R.id.etPassword);   //Password EditText
        edit_email = findViewById(R.id.email);   //email EditText
        edit_name =  findViewById(R.id.name);   //name EditText
        getStarted = findViewById(R.id.getStarted);
        getStarted.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String save_name = edit_name.getText().toString();
                //System.out.println(""+save_name);
                String save_email = edit_email.getText().toString();
                //System.out.println(""+save_email);
                String save_password = edit_password.getText().toString();
                //System.out.println(""+save_password);

                //If and else are used to check if all the three text field are empty or not
                if (save_name.equals("") || save_email.equals("") || save_password.equals("")) {
                    try{
                        Toast.makeText(MainActivity.this, "Please Enter the Details", Toast.LENGTH_SHORT).show();
                    }
                    catch (Exception e)
                    {}
                }
                else {
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("name", save_name);
                    editor.putString("password", save_password);
                    editor.putString("email", save_email);
                    editor.putString("gender", gender);
                    editor.commit();

                    progressBar = new ProgressDialog(v.getContext());//Create new object of progress bar type
                    progressBar.setCancelable(false);//Progress bar cannot be cancelled by pressing any where on screen
                    progressBar.setMessage("Please Wait...");//Title shown in the progress bar
                    progressBar.setProgressStyle(ProgressDialog.STYLE_SPINNER);//Style of the progress bar
                    progressBar.setProgress(0);//attributes
                    progressBar.setMax(100);//attributes
                    progressBar.show();//show the progress bar
                    //This handler will add a delay of 3 seconds
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            //Intent start to open the navigation drawer activity
                            progressBar.cancel();//Progress bar will be cancelled (hide from screen) when this run function will execute after 3.5seconds
                            Intent intent = new Intent(MainActivity.this, navigation_menu.class);
                            startActivity(intent);
                            finish();

                        }
                    }, 3500);

                }

            }
        });

    }

    public void LoginActivity(View view) {
        setContentView(R.layout.activity_second_main);
        final SharedPreferences sharedPreferences = getSharedPreferences("Content_main", Context.MODE_PRIVATE);//reference to shared preference file

        edit_email = findViewById(R.id.email);   //email EditText
        edit_password2 = findViewById(R.id.etPassword);
        forget = findViewById(R.id.forget);
        Continue = findViewById(R.id.Continue);

        try {
            Continue.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    String local_pass2 = edit_password2.getText().toString();
                    String local_email2 = edit_email.getText().toString();

                    if (sharedPreferences.getString("password", Default).equals(local_pass2)&&sharedPreferences.getString("email", Default).equals(local_email2)) {

                        progressBar = new ProgressDialog(v.getContext());//Create new object of progress bar type
                        progressBar.setCancelable(false);//Progress bar cannot be cancelled by pressing any wher on screen
                        progressBar.setMessage("Please Wait...");//Tiitle shown in the progress bar
                        progressBar.setProgressStyle(ProgressDialog.STYLE_SPINNER);//Style of the progress bar
                        progressBar.setProgress(0);//attributes
                        progressBar.setMax(100);//attributes
                        progressBar.show();//show the progress bar
                        //This handler will add a delay of 3 seconds
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                //Intent start to open the navigation drawer activity
                                progressBar.cancel();//Progress bar will be cancelled (hide from screen) when this run function will execute after 3.5seconds
                                Intent intent = new Intent(MainActivity.this, navigation_menu.class);
                                startActivity(intent);
                                finish();
                            }
                        }, 2500);

                    } else {
                        Toast.makeText(MainActivity.this, "Please Enter correct password", Toast.LENGTH_SHORT).show();
                    }

                }
            });
        } catch (Exception e) {
            Toast.makeText(MainActivity.this, "Warning", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }

        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                doubleBackToExitPressedOnce = false;
            }
        }, 4000);

    }





}
