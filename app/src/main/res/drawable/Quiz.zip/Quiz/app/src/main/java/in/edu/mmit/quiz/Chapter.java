package in.edu.mmit.quiz;

public class Chapter{
    int chapter_id;
    String chapter_name;
    int subject_id;
    Chapter(int chapter_id,String chapter_name,int subject_id){
        this.chapter_id=chapter_id;
        this.chapter_name=chapter_name;
        this.subject_id=subject_id;
    }
}