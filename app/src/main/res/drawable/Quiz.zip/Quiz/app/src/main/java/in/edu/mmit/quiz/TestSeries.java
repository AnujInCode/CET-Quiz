package in.edu.mmit.quiz;


import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import androidx.core.widget.NestedScrollView;
import androidx.appcompat.app.AppCompatActivity;

import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;


import io.github.kexanie.library.MathView;
import io.github.krtkush.lineartimer.LinearTimer;
import io.github.krtkush.lineartimer.LinearTimerView;


public class TestSeries extends AppCompatActivity {
    List<Question_info> Questions;
    ArrayList<Integer> Ans=new ArrayList<Integer>(30);
    ArrayList<String> Chapters;
    MathView Ques,OptA,OptB,OptC,OptD;
    Button Bookmark,Finish;
    LinearLayout l1,l2,l3,l4;
    RelativeLayout RL;
    TextView timer;
    Bookmark_Ret bmark;
    int i=0;
    int time=30;
    ArrayList<Question_info> Answered;
    TextView tt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_series);
        Intent intent = getIntent();//recieving the intent send by the Navigation activity
        RetrieveQuestion Question_info=new RetrieveQuestion(this);
        Answered=new ArrayList<Question_info>();
        final AlertDialog.Builder dialog = new AlertDialog.Builder(this).setTitle("Test Series").setMessage("Answer as Many Question as You Can within Time Limit");

        final AlertDialog alert = dialog.create();
        alert.show();

        final Handler handler  = new Handler();
        final Runnable runnable = new Runnable() {
            @Override
            public void run() {
                if (alert.isShowing()) {
                    alert.dismiss();
                }
            }
        };

        alert.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                handler.removeCallbacks(runnable);
            }
        });

        handler.postDelayed(runnable, 3000);


        Questions= Question_info.Retrieve_Ser();
        for (int i = 0; i < Questions.size(); i++) {
            Ans.add(999);
        }


        tt=findViewById(R.id.Qid);
        l1=(LinearLayout)findViewById(R.id.ll1);
        l2=(LinearLayout)findViewById(R.id.ll2);
        l3=(LinearLayout)findViewById(R.id.ll3);
        l4=(LinearLayout)findViewById(R.id.ll4);
        RL=findViewById(R.id.content);
        Bookmark=findViewById(R.id.bookmark);
        Ques=findViewById(R.id.KaTeX_Ques);
        bmark=new Bookmark_Ret(this);
        OptA=findViewById(R.id.KaTeX_OptA);
        OptB=findViewById(R.id.KaTeX_OptB);
        OptC=findViewById(R.id.KaTeX_OptC);
        OptD=findViewById(R.id.KaTeX_OptD);
        Finish=findViewById(R.id.finish);
        timer=findViewById(R.id.timer);
        OptA.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                l1.callOnClick();
                return false;
            }
        });
        OptB.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                l2.callOnClick();
                return false;
            }
        });        OptC.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                l3.callOnClick();
                return false;
            }
        });        OptD.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                l4.callOnClick();
                return false;
            }
        });
                 done();
                check();
                Disp();
                RL.setVisibility(View.VISIBLE);
                Finish.setVisibility(View.VISIBLE);


                new CountDownTimer(30000*2*60, 1000) {

                    public void onTick(long millisUntilFinished) {
                        String text = String.format(Locale.getDefault(), "%02d:%02d",
                                TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished) % 60,
                                TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished) % 60);
                        timer.setText(text);
                    }

                    public void onFinish() {
                        endTest();
                    }
                }.start();

        Finish.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                    new AlertDialog.Builder(TestSeries.this)
                            .setTitle("Do You Want To Finish ?")
                            .setMessage("You Still Have Some Time !!")
                            .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    endTest();
                                }
                            }).setNegativeButton("No", null).show();

            }
        });

        Bookmark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bmark.mark(Questions.get(i));
                Disp();
            }
        });

        l1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Ans.set(i,(Ans.get(i)!=0?0:999));
                checkans();
                Answered.add(Questions.get(i));

                i++;
                check();
            }
        });
        l2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Ans.set(i,(Ans.get(i)!=1?1:999));
                checkans();
                Answered.add(Questions.get(i));

                i++;
                check();

            }
        });
        l3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Ans.set(i,(Ans.get(i)!=2?2:999));
                checkans();
                Answered.add(Questions.get(i));

                i++;
                check();

            }
        });
        l4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Ans.set(i,(Ans.get(i)!=3?3:999));
                checkans();
                Answered.add(Questions.get(i));

                i++;
                check();


            }
        });



    }

    void endTest()
    {
        Intent intent = new Intent(TestSeries.this, Finish.class);

        intent.putIntegerArrayListExtra("Ans",(ArrayList<Integer>)Ans);

        intent.putExtra("Questions",(ArrayList<Question_info>)Answered);
        startActivity(intent);

        finish();
    }

    public String checkDigit(int number) {
        return number <= 9 ? "0" + number : String.valueOf(number);
    }
    void clear()
    {
        l1.setBackgroundColor(Color.parseColor("#FFFFFF"));
        l2.setBackgroundColor(Color.parseColor("#FFFFFF"));
        l3.setBackgroundColor(Color.parseColor("#FFFFFF"));
        l4.setBackgroundColor(Color.parseColor("#FFFFFF"));

    }
    public void Disp()
    {
        Boolean a=bmark.check(Questions.get(i).Question_ID);
        if(a==true)
        {
            Bookmark.setBackgroundResource(R.drawable.bookmark_add);

        }
        else{
            Bookmark.setBackgroundResource(R.drawable.bookmarked);


        }
    }
    protected void check() {

        tt.setText("Q "+(i+1));
        Ques.setText(gettex(Questions.get(i).Que,String.valueOf(i)));
        OptA.setText(gettex(Questions.get(i).OptA,"A"));
        OptB.setText(gettex(Questions.get(i).OptB,"B"));
        OptC.setText(gettex(Questions.get(i).OptC,"C"));
        OptD.setText(gettex(Questions.get(i).OptD,"D"));
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                clear();

            }
        }, 300);
        Disp();


    }
    String gettex(String tex,String x){

        return tex;
    }
    @Override
    protected void onPause() {
        super.onPause();

    }

    @Override
    protected void onRestart() {
        super.onRestart();

    }




    @Override
    public void onBackPressed(){
        new AlertDialog.Builder(TestSeries.this)
                .setTitle("Alert !!!")
                .setMessage("Do u want to exit ")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        endTest();
                    }

                }).setNegativeButton("No", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.cancel();
            }

        })
                .show();
    }
    public void checkans()
    {

        switch(Ans.get(i)){

            case 0:
                l1.setBackgroundColor(Color.parseColor("#7CFC00"));
                break;

            case 1:
                l2.setBackgroundColor(Color.parseColor("#7CFC00"));

                break;
            case 2:
                l3.setBackgroundColor(Color.parseColor("#7CFC00"));

                break;
            case 3:
                l4.setBackgroundColor(Color.parseColor("#7CFC00"));
                break;

        }
    }
    public void done()
    {
        Ques.config(
                "MathJax.Hub.Config({\n"+
                        "  jax: [\"input/TeX\",\"output/HTML-CSS\"],\n" +

                        "  \"HTML-CSS\": {scale: 100, linebreaks: { automatic: true } },\n"+
                        "    displayAlign: \"left\""+
                        "});");


        OptD.config(
                "MathJax.Hub.Config({\n"+
                        "  \"HTML-CSS\": {scale: 100, linebreaks: { automatic: true } },\n"+
                        "  jax: [\"input/TeX\",\"output/HTML-CSS\"],\n" +
                        "});");

        OptA.config(
                "MathJax.Hub.Config({\n"+
                        "  \"HTML-CSS\": {scale: 100, linebreaks: { automatic: true } },\n"+
                        "  jax: [\"input/TeX\",\"output/HTML-CSS\"],\n" +
                        "});");

        OptB.config(
                "MathJax.Hub.Config({\n"+
                        "  \"HTML-CSS\": {scale: 100, linebreaks: { automatic: true } },\n"+
                        "  jax: [\"input/TeX\",\"output/HTML-CSS\"],\n" +
                        "});");
        OptC.config(
                "MathJax.Hub.Config({\n"+
                        "  \"HTML-CSS\": {scale: 100, linebreaks: { automatic: true } },\n"+
                        "  jax: [\"input/TeX\",\"output/HTML-CSS\"],\n" +
                        "});");

    }
}