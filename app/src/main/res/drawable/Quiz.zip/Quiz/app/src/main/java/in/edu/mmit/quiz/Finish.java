package in.edu.mmit.quiz;


import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import androidx.core.widget.NestedScrollView;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


import io.github.kexanie.library.MathView;
import io.github.krtkush.lineartimer.LinearTimer;
import io.github.krtkush.lineartimer.LinearTimerView;


public class Finish extends AppCompatActivity {
    List<Question_info> Questions;
    ArrayList<Integer> Ans=new ArrayList<Integer>(30);
    ArrayList<String> Chapters;
    MathView Ques,OptA,OptB,OptC,OptD,Hint;
    Button next,previous,Play,Bookmark,Finish,close;
    ImageView Hint_image;
    LinearLayout l1,l2,l3,l4;
    RelativeLayout RL;
    LinearTimerView linearTimerView ;
    LinearTimer linearTimer;
    Bookmark_Ret bmark;
    int i=0;
    TextView tt;
    TextView timer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);
        Intent intent = getIntent();//recieving the intent send by the Navigation activity
      Questions=(ArrayList<Question_info>) intent.getSerializableExtra("Questions");
         Ans=(ArrayList<Integer>) intent.getIntegerArrayListExtra("Ans");
        Log.d( "Values ",String.valueOf(Questions.size()));
        int correct=0;
        for (int i=0;i<Questions.size();++i)
        {
            String ans=Questions.get(i).Ans;
            if(ans.equals("A")&&Ans.get(i)==0){
                correct++;
            }
            if(ans.equals("B")&&Ans.get(i)==1){
                correct++;
            }
            if(ans.equals("C")&&Ans.get(i)==2){
                correct++;
            }
            if(ans.equals("D")&&Ans.get(i)==3){
                correct++;
            }
        }
        int val=Collections.frequency(Ans,999);

        new AlertDialog.Builder(this)
                .setTitle("Test Finished")
                .setMessage("You Answered : "+(Ans.size()-val)+" Questions\n"+"You Got "+correct+" Correct\n" )
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                }).setNegativeButton("No", null).show();

        tt=findViewById(R.id.Qid);
        l1=(LinearLayout)findViewById(R.id.ll1);
        l2=(LinearLayout)findViewById(R.id.ll2);
        l3=(LinearLayout)findViewById(R.id.ll3);
        l4=(LinearLayout)findViewById(R.id.ll4);
        Play=(Button)findViewById(R.id.play_button);
        RL=findViewById(R.id.content);
        Bookmark=findViewById(R.id.bookmark);
        Ques=findViewById(R.id.KaTeX_Ques);
        bmark=new Bookmark_Ret(this);
        OptA=findViewById(R.id.KaTeX_OptA);
        OptB=findViewById(R.id.KaTeX_OptB);
        OptC=findViewById(R.id.KaTeX_OptC);
        OptD=findViewById(R.id.KaTeX_OptD);
        Hint=findViewById(R.id.Hint);
        next=findViewById(R.id.Next);
        previous=findViewById(R.id.Previous);
        close=findViewById(R.id.close);
        close.setVisibility(View.VISIBLE);
        Finish=findViewById(R.id.finish);
        Play.setVisibility(View.GONE);
        RL.setVisibility(View.VISIBLE);
        Finish.setVisibility(View.GONE);
        timer=findViewById(R.id.timer);
        timer.setVisibility(View.GONE);
        Bookmark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bmark.mark(Questions.get(i));
                Disp();
            }
        });
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               finish();
            }
        });
        check();


        next.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                i++;
                check();
            }
        });

        previous.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                i--;
                check();
            }
        });
        next.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                i=Questions.size()-1;
                check();
                return true;
            }
        });


        previous.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                i=0;
                check();
                return true;
            }
        });

    }


    public void Disp()
    {
        Boolean a=bmark.check(Questions.get(i).Question_ID);
        if(a==true)
        {
            Bookmark.setBackgroundResource(R.drawable.bookmark_add);

        }
        else{
            Bookmark.setBackgroundResource(R.drawable.bookmarked);


        }
    }
    protected void check() {
        clear();
        if(i==0){
            previous.setEnabled(false);            next.setEnabled(true);
        }
        else if(i== Questions.size()-1){
            next.setEnabled(false);            previous.setEnabled(true);
        }
        else{
            previous.setEnabled(true);
            next.setEnabled(true);
        }
        tt.setText("Q "+(i+1));
        Ques.setText(gettex(Questions.get(i).Que,String.valueOf(i)));
        OptA.setText(gettex(Questions.get(i).OptA,"A"));
        OptB.setText(gettex(Questions.get(i).OptB,"B"));
        OptC.setText(gettex(Questions.get(i).OptC,"C"));
        OptD.setText(gettex(Questions.get(i).OptD,"D"));

            Hint.setText(Questions.get(i).Hint);


        Disp();
        checkWrong();
        checkans();


    }
    String gettex(String tex,String x){

        return tex;
    }
    @Override
    protected void onPause() {
        super.onPause();
        SharedPreferences sp = getSharedPreferences("Score", Context.MODE_PRIVATE);

    }

    @Override
    protected void onRestart() {
        super.onRestart();
        SharedPreferences sp = getSharedPreferences("Score", Context.MODE_PRIVATE);

    }


    public void checkWrong()
    {

        switch(Ans.get(i)){

            case 0:
                l1.setBackgroundColor(Color.parseColor("#ff0000"));
                break;

            case 1:
                l2.setBackgroundColor(Color.parseColor("#ff0000"));

                break;
            case 2:
                l3.setBackgroundColor(Color.parseColor("#ff0000"));

                break;
            case 3:
                l4.setBackgroundColor(Color.parseColor("#ff0000"));
                break;

        }
    }
    public void checkans()
    {

        switch(Questions.get(i).Ans){

            case "A":
                l1.setBackgroundColor(Color.parseColor("#7CFC00"));
                break;

            case "B":
                l2.setBackgroundColor(Color.parseColor("#7CFC00"));

                break;
            case "C":
                l3.setBackgroundColor(Color.parseColor("#7CFC00"));

                break;
            case "D":
                l4.setBackgroundColor(Color.parseColor("#7CFC00"));
                break;

        }
    }
    @Override
    public void onBackPressed(){
        new AlertDialog.Builder(Finish.this)
                .setTitle("Alert !!!")
                .setMessage("Do u want to exit ")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        finish();
                    }

                }).setNegativeButton("No", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.cancel();
            }

        })
                .show();
    }
    void clear()
    {
        l1.setBackgroundColor(Color.parseColor("#FFFFFF"));
        l2.setBackgroundColor(Color.parseColor("#FFFFFF"));
        l3.setBackgroundColor(Color.parseColor("#FFFFFF"));
        l4.setBackgroundColor(Color.parseColor("#FFFFFF"));

    }

    public void done()
    {
        Ques.config(
                "MathJax.Hub.Config({\n"+
                        "  jax: [\"input/TeX\",\"output/HTML-CSS\"],\n" +

                        "  \"HTML-CSS\": {scale: 100, linebreaks: { automatic: true } },\n"+
                        "    displayAlign: \"left\""+
                        "});");


        OptD.config(
                "MathJax.Hub.Config({\n"+
                        "  \"HTML-CSS\": {scale: 100, linebreaks: { automatic: true } },\n"+
                        "  jax: [\"input/TeX\",\"output/HTML-CSS\"],\n" +
                        "});");

        OptA.config(
                "MathJax.Hub.Config({\n"+
                        "  \"HTML-CSS\": {scale: 100, linebreaks: { automatic: true } },\n"+
                        "  jax: [\"input/TeX\",\"output/HTML-CSS\"],\n" +
                        "});");

        OptB.config(
                "MathJax.Hub.Config({\n"+
                        "  \"HTML-CSS\": {scale: 100, linebreaks: { automatic: true } },\n"+
                        "  jax: [\"input/TeX\",\"output/HTML-CSS\"],\n" +
                        "});");
        OptC.config(
                "MathJax.Hub.Config({\n"+
                        "  \"HTML-CSS\": {scale: 100, linebreaks: { automatic: true } },\n"+
                        "  jax: [\"input/TeX\",\"output/HTML-CSS\"],\n" +
                        "});");

    }
}