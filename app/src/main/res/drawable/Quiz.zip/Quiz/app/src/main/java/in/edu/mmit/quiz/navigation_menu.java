package in.edu.mmit.quiz;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import com.google.android.material.navigation.NavigationView;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class navigation_menu extends AppCompatActivity   implements NavigationView.OnNavigationItemSelectedListener{


    TextView nav_header_nam, nav_header_emal;
    ImageView nav_header_imag;
    Button unit, c2, c3, c4, c5;
    private ProgressDialog progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_navigation_menu);
        SharedPreferences sharedPreferences = getSharedPreferences("Content_main", Context.MODE_PRIVATE);
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        SharedPreferences sp = getSharedPreferences("Score", Context.MODE_PRIVATE);

        //Set name,email,image in  the navigation side drawer to those we enter in the login page
        String nav_header_name = sharedPreferences.getString("name", "Anuj");
        String nav_header_email = sharedPreferences.getString("email", "anujchampjain@gmail.com");
        String nav_header_gender = sharedPreferences.getString("gender", "Male");
        View header = navigationView.getHeaderView(0);//Used to get a reference to navigation header
        nav_header_nam = header.findViewById(R.id.nav_header_name);
        nav_header_emal = header.findViewById(R.id.nav_header_email);
        nav_header_imag = header.findViewById(R.id.nav_header_image);
        nav_header_nam.setText(nav_header_name);
        nav_header_emal.setText(nav_header_email);
        if (nav_header_gender.equals("Male")) {
            nav_header_imag.setImageResource(R.drawable.man);
        } else {
            nav_header_imag.setImageResource(R.drawable.female);
        }
        unit = findViewById(R.id.unit);
        c2 = findViewById(R.id.series);
        c3 = findViewById(R.id.papers);
        c4 = findViewById(R.id.bookmark);
        c5 = findViewById(R.id.graph);


//
        unit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //To show button click
                               // new Handler().postDelayed(new Runnable() {@Override public void run(){}}, 400);


                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Intent intent = new Intent(navigation_menu.this, SubjectOpt.class);
                        intent.putExtra("Option", "UnitTest");//by this statement we are sending the name of the button that invoked the new Questions.java activity "Message" is defined by the name of the package + MESSAGE
                        startActivity(intent);
                    }
                }, 0);
            }
        });
        c4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //To show button click
                // new Handler().postDelayed(new Runnable() {@Override public void run(){}}, 400);


                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Intent intent = new Intent(navigation_menu.this, Bookmarks.class);
                        intent.putExtra("Option", "Bookmark");//by this statement we are sending the name of the button that invoked the new Questions.java activity "Message" is defined by the name of the package + MESSAGE
                        startActivity(intent);
                    }
                }, 0);
            }
        });
//
        c2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //To show button click
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Intent intent = new Intent(navigation_menu.this, TestSeries.class);
                        intent.putExtra("Option", "UnitTest");//by this statement we are sending the name of the button that invoked the new Questions.java activity "Message" is defined by the name of the package + MESSAGE
                        startActivity(intent);
                    }
                }, 0);
            }});
//
//
//        c3.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                //To show button click
//                new Handler().postDelayed(new Runnable() {@Override public void run(){}}, 400);
//
//                progressBar = new ProgressDialog(v.getContext());//Create new object of progress bar type
//                progressBar.setCancelable(false);//Progress bar cannot be cancelled by pressing any wher on screen
//                progressBar.setMessage("Getting Questions Ready ...");//Title shown in the progress bar
//                progressBar.setProgressStyle(ProgressDialog.STYLE_SPINNER);//Style of the progress bar
//                progressBar.setProgress(0);//attributes
//                progressBar.setMax(100);//attributes
//                progressBar.show();//show the progress bar
//                //This handler will add a delay of 3 seconds
//                new Handler().postDelayed(new Runnable() {
//                    @Override
//                    public void run() {
//                        //Intent start to open the navigation drawer activity
//                        progressBar.cancel();//Progress bar will be cancelled (hide from screen) when this run function will execute after 3.5seconds
//                        Intent intent = new Intent(Navigation_Activity.this, Questions.class);
//                        intent.putExtra(Message, "c3");
//                        startActivity(intent);
//                    }
//                }, 2000);
//            }
//        });
//
//
//        c4.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                //To show button click
//                new Handler().postDelayed(new Runnable() {@Override public void run(){}}, 400);
//
//                progressBar = new ProgressDialog(v.getContext());//Create new object of progress bar type
//                progressBar.setCancelable(false);//Progress bar cannot be cancelled by pressing any wher on screen
//                progressBar.setMessage("Getting Questions Ready ...");//Title shown in the progress bar
//                progressBar.setProgressStyle(ProgressDialog.STYLE_SPINNER);//Style of the progress bar
//                progressBar.setProgress(0);//attributes
//                progressBar.setMax(100);//attributes
//                progressBar.show();//show the progress bar
//                //This handler will add a delay of 3 seconds
//                new Handler().postDelayed(new Runnable() {
//                    @Override
//                    public void run() {
//                        //Intent start to open the navigation drawer activity
//                        progressBar.cancel();//Progress bar will be cancelled (hide from screen) when this run function will execute after 3.5seconds
//                        Intent intent = new Intent(Navigation_Activity.this, Questions.class);
//                        intent.putExtra(Message, "c4");
//                        startActivity(intent);
//                    }
//                }, 2000);
//            }
//        });
//
//
//        c5.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                //To show button click
//                new Handler().postDelayed(new Runnable() {@Override public void run(){}}, 400);
//
//                progressBar = new ProgressDialog(v.getContext());//Create new object of progress bar type
//                progressBar.setCancelable(false);//Progress bar cannot be cancelled by pressing any wher on screen
//                progressBar.setMessage("Getting Questions Ready ...");//Title shown in the progress bar
//                progressBar.setProgressStyle(ProgressDialog.STYLE_SPINNER);//Style of the progress bar
//                progressBar.setProgress(0);//attributes
//                progressBar.setMax(100);//attributes
//                progressBar.show();//show the progress bar
//                //This handler will add a delay of 3 seconds
//                new Handler().postDelayed(new Runnable() {
//                    @Override
//                    public void run() {
//                        //Intent start to open the navigation drawer activity
//                        progressBar.cancel();//Progress bar will be cancelled (hide from screen) when this run function will execute after 3.5seconds
//                        Intent intent = new Intent(Navigation_Activity.this, Questions.class);
//                        intent.putExtra(Message, "c5");
//                        startActivity(intent);
//                    }
//                }, 2000);
//            }
//        });

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

    if (id == R.id.nav_Setting) {}
            /*  startActivity(new Intent(this,Setting.class));*/
          //  startActivity(new Intent(this, Setting_activity.class));

//        } else if (id == R.id.nav_share) {
//            //shareApplication();
//            Intent intent = new Intent(android.content.Intent.ACTION_SEND);
//            intent.setData(Uri.parse("mailto:"));
//            intent.setType("message/rfc822");
//            intent.putExtra(Intent.EXTRA_SUBJECT, "QuizBook");
//            System.out.println(""+R.string.email_content);
//            intent.putExtra(Intent.EXTRA_TEXT, ""+getText(R.string.email_content)+getText(R.string.link)+getText(R.string.last_content));
//            Intent chooser = Intent.createChooser(intent, "Share using");
//            startActivity(chooser);
//
//
//        } else if (id == R.id.nav_feedback) {
//            Intent intent = new Intent(Intent.ACTION_SEND);
//            intent.setData(Uri.parse("mailto:"));
//            String[] recipents = {"kvikesh800@gmail.com"};
//            intent.setType("message/rfc822");
//            intent.putExtra(Intent.EXTRA_EMAIL, recipents);
//            intent.putExtra(Intent.EXTRA_SUBJECT, "QuizBook Reviews");
//            Intent chooser = Intent.createChooser(intent, "Send Feedback Via");
//            startActivity(chooser);
//
//        }


        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }



}

