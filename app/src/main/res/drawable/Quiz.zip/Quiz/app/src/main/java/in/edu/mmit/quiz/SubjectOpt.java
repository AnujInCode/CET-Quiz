package in.edu.mmit.quiz;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;
import java.util.List;

public class SubjectOpt extends AppCompatActivity {
    Chap_Ret chapters;
    ArrayList<Chapter> chapter ;

    String Type;
    public static List<String> mSelectedItems = new ArrayList<String>(); //list of selected item IDs in multiselection dialog

    Button Physics,Chemistry,Maths;
    private ProgressDialog progressBar;
    String type="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_subject_opt);
        Intent intent = getIntent();//recieving the intent send by the Navigation activity
        Type = intent.getStringExtra("Option");//converting that intent message to string using the getStringExtra() method

        Physics=findViewById(R.id.physics);
        Chemistry=findViewById(R.id.chemistry);
        Maths=findViewById(R.id.maths);
        chapters = new Chap_Ret(this);


        Physics.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View v) {

                chapter=(ArrayList<Chapter>) chapters.Retrieve(1);

                call("physics",v);

            }
        });

        Chemistry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chapter=(ArrayList<Chapter>)chapters.Retrieve(2);


                     call("chemistry",v);

            }
        });
        Maths.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chapter=(ArrayList<Chapter>)chapters.Retrieve(3);


                 call("maths",v);

            }
        });

    }
    public  void call(String sub,View v)
    {
                mSelectedItems = new ArrayList();

                   String[] stringArray =new String[chapter.size()];
            for(int i=0; i<chapter.size();++i)
            {
                stringArray[i]=chapter.get(i).chapter_name;
            }
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Select Chapters for test");
        builder.setMultiChoiceItems( stringArray, null, new DialogInterface.OnMultiChoiceClickListener() {
        @Override
        public void onClick(DialogInterface dialog, int index, boolean isChecked) {
            if (isChecked) {
                // If the the item is checked, add its ID to the selected IDs
                Log.d("getSelectedItems: ", String.valueOf(chapter.get(index).chapter_id));

                mSelectedItems.add(String.valueOf(chapter.get(index).chapter_id));
            } else if (mSelectedItems.contains(index)) {
                // Else, if the ID of the item is already in the array, remove it
                mSelectedItems.remove(chapter.get(index).chapter_id);
            }
        }
    })
                .setPositiveButton("Next",new DialogButtonClickHandler())
                .setNegativeButton("Back",new DialogButtonClickHandler())
                .show();

    }
    public class DialogButtonClickHandler implements DialogInterface.OnClickListener
    {
        public void onClick( DialogInterface dialog, int clicked )
        {
            switch( clicked )
            {
                case DialogInterface.BUTTON_POSITIVE:
                    List<String>List = getSelectedItems();
                    Intent intent = new Intent(SubjectOpt.this, test.class);

                    Log.d("getSelectedItems: ", List.toString());

                    intent.putStringArrayListExtra("Chapter_ID",(ArrayList<String>)List);
                    startActivity(intent);
                    finish();
                    break;

                case DialogInterface.BUTTON_NEGATIVE:
                    dialog.dismiss();
                    break;

            }
        }
    }
    protected List<String> getSelectedItems(){


        List<String> temp=new ArrayList<>(mSelectedItems);
        mSelectedItems.clear();

        Log.d("getSelectedItems: ", temp.toString());
        return temp;
    }
}
//
//    @Override
//    protected Dialog onCreateDialog( int id )
//    {
//        mSelectedItems = new ArrayList();
//
//        return  new AlertDialog.Builder( this )
//                .setTitle( "Contacts" )
//                .setMultiChoiceItems( contactArray, null, new DialogSelectionClickHandler() {
//                    @Override
//                    public void onClick(DialogInterface dialog, int which,
//                                        boolean isChecked) {
//                        if (isChecked) {
//                            // If the the item is checked, add its ID to the selected IDs
//                            mSelectedItems.add(which);
//                        } else if (mSelectedItems.contains(which)) {
//                            // Else, if the ID of the item is already in the array, remove it
//                            mSelectedItems.remove(Integer.valueOf(which));
//                        }
//                    }
//                })
//                .setPositiveButton( "OK", new DialogButtonClickHandler() )
//                .setNegativeButton("Cancel", new DialogButtonClickHandler() )
//                .create();
//    }
//
//    //We enter here every time the dialog is opened
//    @Override
//    protected void onPrepareDialog(int id, Dialog dialog) {
//        //clear all previously selected item IDs
//        mSelectedItems.clear();
//
//        AlertDialog alert = (AlertDialog) dialog;
//
//        //get List of dialog checked items
//        ListView dialogListView = alert.getListView();
//
//        //uncheck all previously checked items
//        for(int i = 0 ; i < dialogListView.getCount(); i++){
//            dialogListView.setItemChecked(i, false);
//        }
//
//    }
////nothing to do here, we expect the result - list of checked items on click of OK button
//public class DialogSelectionClickHandler implements DialogInterface.OnMultiChoiceClickListener
//{
//    public void onClick( DialogInterface dialog, int clicked, boolean selected )
//    {
//        Log.i( "ME", contactArray[ clicked ] + " selected: " + selected );
//    }
//}
//
////Here we take the result - the list of checked items, from which we construct the string with selected emails
////separated with coma

//    //we build the result. It is a string of selected items. Each item is a string with format - "name \n email".
//    //We take only the email in the result string;
//    protected String getSelectedItems(){
//
//        String emailList = "";
//
//        for( int i = 0; i < mSelectedItems.size(); i++ ){ //number of selected items in the dialog.
//
//            int j = (int) mSelectedItems.get(i); // get the ID of current selected item. It is equal to j;
//
//            Log.i( "ME", contactArray[ i ] + " selected: " +  contactArray[ j ]);
//
//            String [] nameEmail =  contactArray[ j ].split("\n");  //get email only
//            emailList = emailList + nameEmail[1] + ","; // createte a string with selected emails, separated with coma.
//
//        }
//        //remove the last coma in the string
//        if (emailList.length() > 1) {
//            emailList = emailList.substring(0, emailList.length() - 1);
//        }
//        //if nothing selected return emty string.
//        if (emailList.indexOf("@") < 1){
//            emailList = "";
//        }
//
//        return emailList;
//    }