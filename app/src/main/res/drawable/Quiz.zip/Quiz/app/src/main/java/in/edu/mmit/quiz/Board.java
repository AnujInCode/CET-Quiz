package in.edu.mmit.quiz;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class Board extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_board);
    }
}
