package in.edu.mmit.quiz;


import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;
import android.util.Log;

import com.readystatesoftware.sqliteasset.SQLiteAssetHelper;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class RetrieveQuestion  extends SQLiteAssetHelper {
    private static final String Database_name = "DBase.db";//NAME of database stored in Assets folder
    private static final String Table_name = "question_info";//name of table

    private static final int version = 1;//version of database signifies if there is any upgradation or not
    private Context context;//Context object to get context from Question Activity

    public RetrieveQuestion(Context context) {//constructor
        super(context, Database_name, context.getExternalFilesDir(null).getAbsolutePath(), null, version);
        this.context = context;
    }


    public List<Question_info> Retrieve(ArrayList<String> Chapters)//Used to read the data from the Des.db file where id is given and we choose id randomly
    {
        Log.d("Results : ",String.valueOf(Chapters));

        SQLiteDatabase db = getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        String[] sqlSelect = {"QUESTION_ID", "  QUESTION", "  OPTIONA", "  OPTIONB", "  OPTIONC", "  OPTIOND", "  ANSWER", "  HINT", "  QUESTION_LEVEL", "  SUBJECT_ID", " CHAPTER_ID", "  TOPIC_ID", "  ISQUESTIONASIMAGE", "  QUESTIONIMAGEPATH", "  ISOPTIONASIMAGE", "  OPTIONIMAGEPATH", "  ISHINTASIMAGE", "  HINTIMAGEPATH", "   ATTEMPTEDVALUE", "  QUESTION_TYPE", "   QUESTION_YEAR"};
        String where="";
        String[] query=new String[25];
        qb.setTables(Table_name);
        Cursor cursor=null;
        int limitQ = Math.round(30 / Chapters.size());

        int count1=0;

        String ff="";
        ArrayList<Question_info> Que = new ArrayList<>();
        int i=0;
        for(int j=0;j<Chapters.size();j++)
        {
                if(j==Chapters.size()-1)
                    limitQ=30-count1;
                ff= String.valueOf(Chapters.get(j));

                     where = " ATTEMPTEDVALUE = 0 AND CHAPTER_ID = '"+ff+"'";

//                    query[j]="SELECT * FROM (SELECT QUESTION_ID, QUESTION, OPTIONA, OPTIONB, OPTIONC,OPTIOND, ANSWER, HINT, QUESTION_LEVEL, SUBJECT_ID, CHAPTER_ID,ATTEMPTEDVALUE, QUESTION_TYPE, QUESTION_YEAR, ISQUESTIONASIMAGE,QUESTIONIMAGEPATH,ISOPTIONASIMAGE,OPTIONIMAGEPATH,ISHINTASIMAGE,HINTIMAGEPATH"+
//                            " FROM question_info WHERE ATTEMPTEDVALUE=0 AND CHAPTER_ID="+ ff+" limit "+limitQ+") UNION ";
                    count1+=limitQ;
                 cursor= qb.query(db, sqlSelect, where, null, null, null, null);
            if (cursor.moveToFirst()) {
                i=1;

                Que.add(new Question_info(
                        cursor.getInt(cursor.getColumnIndex("QUESTION_ID")),

                        cursor.getInt(cursor.getColumnIndex("QUESTION_LEVEL")),

                        cursor.getInt(cursor.getColumnIndex("SUBJECT_ID")),

                        cursor.getInt(cursor.getColumnIndex("CHAPTER_ID")),
                        cursor.getInt(cursor.getColumnIndex("TOPIC_ID")),

                        cursor.getInt(cursor.getColumnIndex("ISQUESTIONASIMAGE")),
                        cursor.getInt(cursor.getColumnIndex("ISOPTIONASIMAGE")),

                        cursor.getInt(cursor.getColumnIndex("ISHINTASIMAGE")),
                        cursor.getInt(cursor.getColumnIndex("QUESTION_TYPE")),

                        cursor.getInt(cursor.getColumnIndex("ATTEMPTEDVALUE")),


                        cursor.getString(cursor.getColumnIndex("QUESTION")),
                        cursor.getString(cursor.getColumnIndex("OPTIONA")),

                        cursor.getString(cursor.getColumnIndex("OPTIONB")),
                        cursor.getString(cursor.getColumnIndex("OPTIONC")),


                        cursor.getString(cursor.getColumnIndex("OPTIOND")),
                        cursor.getString(cursor.getColumnIndex("ANSWER")),

                        cursor.getString(cursor.getColumnIndex("HINT")),
                        cursor.getString(cursor.getColumnIndex("QUESTIONIMAGEPATH")),

                        cursor.getString(cursor.getColumnIndex("OPTIONIMAGEPATH")),
                        cursor.getString(cursor.getColumnIndex("HINTIMAGEPATH")),

                        cursor.getString(cursor.getColumnIndex("QUESTION_YEAR"))
                ));
                while (cursor.moveToNext()&&i<limitQ) {
                    i++;
                    Que.add(new Question_info(
                            cursor.getInt(cursor.getColumnIndex("QUESTION_ID")),

                            cursor.getInt(cursor.getColumnIndex("QUESTION_LEVEL")),

                            cursor.getInt(cursor.getColumnIndex("SUBJECT_ID")),

                            cursor.getInt(cursor.getColumnIndex("CHAPTER_ID")),
                            cursor.getInt(cursor.getColumnIndex("TOPIC_ID")),

                            cursor.getInt(cursor.getColumnIndex("ISQUESTIONASIMAGE")),
                            cursor.getInt(cursor.getColumnIndex("ISOPTIONASIMAGE")),

                            cursor.getInt(cursor.getColumnIndex("ISHINTASIMAGE")),
                            cursor.getInt(cursor.getColumnIndex("QUESTION_TYPE")),

                            cursor.getInt(cursor.getColumnIndex("ATTEMPTEDVALUE")),


                            cursor.getString(cursor.getColumnIndex("QUESTION")),
                            cursor.getString(cursor.getColumnIndex("OPTIONA")),

                            cursor.getString(cursor.getColumnIndex("OPTIONB")),
                            cursor.getString(cursor.getColumnIndex("OPTIONC")),


                            cursor.getString(cursor.getColumnIndex("OPTIOND")),
                            cursor.getString(cursor.getColumnIndex("ANSWER")),

                            cursor.getString(cursor.getColumnIndex("HINT")),
                            cursor.getString(cursor.getColumnIndex("QUESTIONIMAGEPATH")),

                            cursor.getString(cursor.getColumnIndex("OPTIONIMAGEPATH")),
                            cursor.getString(cursor.getColumnIndex("HINTIMAGEPATH")),

                            cursor.getString(cursor.getColumnIndex("QUESTION_YEAR"))
                    ));
                }
            }
        }


        Collections.shuffle(Que);

//           Cursor cursor = qb.query(db, sqlSelect, "", null,
//                    null, null, null);
//

        return Que;
        }

    public List<Question_info> Retrieve_Ser()//Used to read the data from the Des.db file where id is given and we choose id randomly
    {

        SQLiteDatabase db = getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        String[] sqlSelect = {"QUESTION_ID", "  QUESTION", "  OPTIONA", "  OPTIONB", "  OPTIONC", "  OPTIOND", "  ANSWER", "  HINT", "  QUESTION_LEVEL", "  SUBJECT_ID", " CHAPTER_ID", "  TOPIC_ID", "  ISQUESTIONASIMAGE", "  QUESTIONIMAGEPATH", "  ISOPTIONASIMAGE", "  OPTIONIMAGEPATH", "  ISHINTASIMAGE", "  HINTIMAGEPATH", "   ATTEMPTEDVALUE", "  QUESTION_TYPE", "   QUESTION_YEAR"};
        String where="";
        String[] query=new String[25];
        qb.setTables(Table_name);
        Cursor cursor=null;

        int count1=0;

        String ff="";
        ArrayList<Question_info> Que = new ArrayList<>();
        int i=0;
        for(int j=1;j<80;j++)
        {

            ff= String.valueOf(j);

            where = " ATTEMPTEDVALUE = 0 AND CHAPTER_ID = '"+ff+"'";

//                    query[j]="SELECT * FROM (SELECT QUESTION_ID, QUESTION, OPTIONA, OPTIONB, OPTIONC,OPTIOND, ANSWER, HINT, QUESTION_LEVEL, SUBJECT_ID, CHAPTER_ID,ATTEMPTEDVALUE, QUESTION_TYPE, QUESTION_YEAR, ISQUESTIONASIMAGE,QUESTIONIMAGEPATH,ISOPTIONASIMAGE,OPTIONIMAGEPATH,ISHINTASIMAGE,HINTIMAGEPATH"+
//                            " FROM question_info WHERE ATTEMPTEDVALUE=0 AND CHAPTER_ID="+ ff+" limit "+limitQ+") UNION ";
            cursor= qb.query(db, sqlSelect, where, null, null, null, null);
            if (cursor.moveToFirst()) {

                Que.add(new Question_info(
                        cursor.getInt(cursor.getColumnIndex("QUESTION_ID")),

                        cursor.getInt(cursor.getColumnIndex("QUESTION_LEVEL")),

                        cursor.getInt(cursor.getColumnIndex("SUBJECT_ID")),

                        cursor.getInt(cursor.getColumnIndex("CHAPTER_ID")),
                        cursor.getInt(cursor.getColumnIndex("TOPIC_ID")),

                        cursor.getInt(cursor.getColumnIndex("ISQUESTIONASIMAGE")),
                        cursor.getInt(cursor.getColumnIndex("ISOPTIONASIMAGE")),

                        cursor.getInt(cursor.getColumnIndex("ISHINTASIMAGE")),
                        cursor.getInt(cursor.getColumnIndex("QUESTION_TYPE")),

                        cursor.getInt(cursor.getColumnIndex("ATTEMPTEDVALUE")),


                        cursor.getString(cursor.getColumnIndex("QUESTION")),
                        cursor.getString(cursor.getColumnIndex("OPTIONA")),

                        cursor.getString(cursor.getColumnIndex("OPTIONB")),
                        cursor.getString(cursor.getColumnIndex("OPTIONC")),


                        cursor.getString(cursor.getColumnIndex("OPTIOND")),
                        cursor.getString(cursor.getColumnIndex("ANSWER")),

                        cursor.getString(cursor.getColumnIndex("HINT")),
                        cursor.getString(cursor.getColumnIndex("QUESTIONIMAGEPATH")),

                        cursor.getString(cursor.getColumnIndex("OPTIONIMAGEPATH")),
                        cursor.getString(cursor.getColumnIndex("HINTIMAGEPATH")),

                        cursor.getString(cursor.getColumnIndex("QUESTION_YEAR"))
                ));
           
            }
        }


        Collections.shuffle(Que);

//           Cursor cursor = qb.query(db, sqlSelect, "", null,
//                    null, null, null);
//

        return Que;
    }

    public Question_info Retrieve(Integer id)//Used to read the data from the Des.db file where id is given and we choose id randomly
    {

        SQLiteDatabase db = getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        String[] sqlSelect = {"QUESTION_ID", "  QUESTION", "  OPTIONA", "  OPTIONB", "  OPTIONC", "  OPTIOND", "  ANSWER", "  HINT", "  QUESTION_LEVEL", "  SUBJECT_ID", " CHAPTER_ID", "  TOPIC_ID", "  ISQUESTIONASIMAGE", "  QUESTIONIMAGEPATH", "  ISOPTIONASIMAGE", "  OPTIONIMAGEPATH", "  ISHINTASIMAGE", "  HINTIMAGEPATH", "   ATTEMPTEDVALUE", "  QUESTION_TYPE", "   QUESTION_YEAR"};
        String where = "";
        qb.setTables(Table_name);
        Cursor cursor = null;


        Question_info Que = null;
        int i = 0;
        where = "QUESTION_ID = '" + id + "'";
        cursor= qb.query(db, sqlSelect, where, null, null, null, null);

        if (cursor.moveToFirst()) {
            i = 1;

            Que = new Question_info(
                    cursor.getInt(cursor.getColumnIndex("QUESTION_ID")),

                    cursor.getInt(cursor.getColumnIndex("QUESTION_LEVEL")),

                    cursor.getInt(cursor.getColumnIndex("SUBJECT_ID")),

                    cursor.getInt(cursor.getColumnIndex("CHAPTER_ID")),
                    cursor.getInt(cursor.getColumnIndex("TOPIC_ID")),

                    cursor.getInt(cursor.getColumnIndex("ISQUESTIONASIMAGE")),
                    cursor.getInt(cursor.getColumnIndex("ISOPTIONASIMAGE")),

                    cursor.getInt(cursor.getColumnIndex("ISHINTASIMAGE")),
                    cursor.getInt(cursor.getColumnIndex("QUESTION_TYPE")),

                    cursor.getInt(cursor.getColumnIndex("ATTEMPTEDVALUE")),


                    cursor.getString(cursor.getColumnIndex("QUESTION")),
                    cursor.getString(cursor.getColumnIndex("OPTIONA")),

                    cursor.getString(cursor.getColumnIndex("OPTIONB")),
                    cursor.getString(cursor.getColumnIndex("OPTIONC")),


                    cursor.getString(cursor.getColumnIndex("OPTIOND")),
                    cursor.getString(cursor.getColumnIndex("ANSWER")),

                    cursor.getString(cursor.getColumnIndex("HINT")),
                    cursor.getString(cursor.getColumnIndex("QUESTIONIMAGEPATH")),

                    cursor.getString(cursor.getColumnIndex("OPTIONIMAGEPATH")),
                    cursor.getString(cursor.getColumnIndex("HINTIMAGEPATH")),

                    cursor.getString(cursor.getColumnIndex("QUESTION_YEAR"))
            );


        }
        return Que;

    }
}

