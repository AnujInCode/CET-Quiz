package in.edu.mmit.quiz;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;

import com.readystatesoftware.sqliteasset.SQLiteAssetHelper;

import java.util.ArrayList;
import java.util.List;

public class Chap_Ret  extends SQLiteAssetHelper {
    private static final String Database_name = "DBase.db";//NAME of database stored in Assets folder
    private static final String Table_name = "chapter_info";//name of table
    private static final String uid = "subject_id";//name of column1

    private static final int version = 1;//version of database signifies if there is any upgradation or not
    private Context context;//Context object to get context from Question Activity
    public Chap_Ret(Context context) {//constructor
        super(context, Database_name, context.getExternalFilesDir(null).getAbsolutePath(), null, version);
        this.context = context;
    }



    public  List<Chapter>  Retrieve(int i)//Used to read the data from the Des.db file where id is given and we choose id randomly
    {

        SQLiteDatabase db = getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();
        String where = "subject_id = '"+i+"' ";

        String [] sqlSelect = {"chapter_id","chapter_name","subject_id"};

        qb.setTables(Table_name);
        Cursor cursor = qb.query(db, sqlSelect, where, null,
                null, null, null);

        ArrayList<Chapter> chap = new ArrayList<>();
        if (cursor.moveToFirst()){
            chap.add(new Chapter(cursor.getInt(cursor.getColumnIndex("chapter_id"))
            ,cursor.getString(cursor.getColumnIndex("chapter_name"))
            ,cursor.getInt(cursor.getColumnIndex("subject_id"))));
            while(cursor.moveToNext()){
                chap.add(new Chapter(cursor.getInt(cursor.getColumnIndex("chapter_id"))
                        ,cursor.getString(cursor.getColumnIndex("chapter_name"))
                        ,cursor.getInt(cursor.getColumnIndex("subject_id"))));      }
        }

        return  chap;
    }
}
