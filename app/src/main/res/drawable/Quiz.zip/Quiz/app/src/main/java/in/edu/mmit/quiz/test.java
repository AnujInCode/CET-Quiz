package in.edu.mmit.quiz;


import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import androidx.core.widget.NestedScrollView;
import androidx.appcompat.app.AppCompatActivity;

import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;


import io.github.kexanie.library.MathView;
import io.github.krtkush.lineartimer.LinearTimer;
import io.github.krtkush.lineartimer.LinearTimerView;


public class test extends AppCompatActivity {
    List<Question_info> Questions;
    ArrayList<Integer> Ans=new ArrayList<Integer>(30);
    ArrayList<String> Chapters;
    MathView Ques,OptA,OptB,OptC,OptD;
    Button next,previous,Play,Bookmark,Finish;
    LinearLayout l1,l2,l3,l4;
    RelativeLayout RL;
    TextView timer;
    Bookmark_Ret bmark;
    int i=0;
    int time=30;

    TextView tt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);
        Intent intent = getIntent();//recieving the intent send by the Navigation activity
        Chapters = intent.getStringArrayListExtra("Chapter_ID");
        RetrieveQuestion Question_info=new RetrieveQuestion(this);
        Questions= Question_info.Retrieve(Chapters);
        for (int i = 0; i < 30; i++) {
            Ans.add(999);
        }


         tt=findViewById(R.id.Qid);
        l1=(LinearLayout)findViewById(R.id.ll1);
        l2=(LinearLayout)findViewById(R.id.ll2);
        l3=(LinearLayout)findViewById(R.id.ll3);
        l4=(LinearLayout)findViewById(R.id.ll4);
        Play=(Button)findViewById(R.id.play_button);
        RL=findViewById(R.id.content);
        Bookmark=findViewById(R.id.bookmark);
         Ques=findViewById(R.id.KaTeX_Ques);
         bmark=new Bookmark_Ret(this);
        OptA=findViewById(R.id.KaTeX_OptA);
        OptB=findViewById(R.id.KaTeX_OptB);
        OptC=findViewById(R.id.KaTeX_OptC);
        OptD=findViewById(R.id.KaTeX_OptD);
        next=findViewById(R.id.Next);
        previous=findViewById(R.id.Previous);
        Finish=findViewById(R.id.finish);
        timer=findViewById(R.id.timer);
        OptA.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                    l1.callOnClick();
                return false;
            }
        });
        OptB.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                l2.callOnClick();
                return false;
            }
        });        OptC.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                l3.callOnClick();
                return false;
            }
        });        OptD.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                l4.callOnClick();
                return false;
            }
        });
        Play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Play.setVisibility(View.GONE);
                done();
                check();
                clear();
                Disp();
                RL.setVisibility(View.VISIBLE);
                Finish.setVisibility(View.VISIBLE);


                new CountDownTimer(30000*2*30, 1000) {

                    public void onTick(long millisUntilFinished) {
                        String text = String.format(Locale.getDefault(), "%02d:%02d",
                                TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished) % 60,
                                TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished) % 60);
                        timer.setText(text);
                    }

                    public void onFinish() {
                      endTest();
                    }
                }.start();




            }
        });
        Bookmark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    bmark.mark(Questions.get(i));
                    Disp();
            }
        });

        l1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Ans.set(i,(Ans.get(i)!=0?0:999));

                checkans();

            }
        });
        l2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Ans.set(i,(Ans.get(i)!=1?1:999));

                checkans();

            }
        });
        l3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Ans.set(i,(Ans.get(i)!=2?2:999));

                checkans();

            }
        });
        l4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Ans.set(i,(Ans.get(i)!=3?3:999));

                checkans();


            }
        });
        next.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                i++;
                check();
            }
        });

        previous.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                i--;
                check();
            }
        });
        next.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                i=29;
                check();
                return true;
            }
        });


        previous.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                i=0;
                check();
                return true;
            }
        });

        Finish.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
               if(Ans.contains(999)==true)
               {
                   new AlertDialog.Builder(test.this)
                           .setTitle("Do You Want To Finish ?")
                           .setMessage("You Have Not Answered All Questions !!")
                           .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                               @Override
                               public void onClick(DialogInterface dialog, int which) {
                                  endTest();
                               }
                           }).setNegativeButton("No", null).show();

               }
               else {
                   new AlertDialog.Builder(test.this)
                           .setTitle("Do You Want To Finish ?")
                           .setMessage("You Still Have Some Time !!")
                           .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                               @Override
                               public void onClick(DialogInterface dialog, int which) {
                                   endTest();
                               }
                           }).setNegativeButton("No", null).show();
               }

            }
        });
    }

    void endTest()
    {
        Intent intent = new Intent(test.this, Finish.class);

        intent.putIntegerArrayListExtra("Ans",(ArrayList<Integer>)Ans);

        intent.putExtra("Questions",(ArrayList<Question_info>)Questions);
        startActivity(intent);

        finish();
    }

    public String checkDigit(int number) {
        return number <= 9 ? "0" + number : String.valueOf(number);
    }
    void clear()
    {
        l1.setBackgroundColor(Color.parseColor("#FFFFFF"));
        l2.setBackgroundColor(Color.parseColor("#FFFFFF"));
        l3.setBackgroundColor(Color.parseColor("#FFFFFF"));
        l4.setBackgroundColor(Color.parseColor("#FFFFFF"));

    }
    public void Disp()
    {
        Boolean a=bmark.check(Questions.get(i).Question_ID);
        if(a==true)
        {
            Bookmark.setBackgroundResource(R.drawable.bookmark_add);

        }
        else{
            Bookmark.setBackgroundResource(R.drawable.bookmarked);


        }
    }
    protected void check() {
        if(i==0){
            previous.setEnabled(false);            next.setEnabled(true);
        }
        else if(i==29){
            next.setEnabled(false);            previous.setEnabled(true);
        }
        else{
            previous.setEnabled(true);
            next.setEnabled(true);
        }
        tt.setText("Q "+(i+1));
        Ques.setText(gettex(Questions.get(i).Que,String.valueOf(i)));
        OptA.setText(gettex(Questions.get(i).OptA,"A"));
        OptB.setText(gettex(Questions.get(i).OptB,"B"));
        OptC.setText(gettex(Questions.get(i).OptC,"C"));
        OptD.setText(gettex(Questions.get(i).OptD,"D"));

        Disp();
        checkans();


    }
    String gettex(String tex,String x){

        return tex;
    }
    @Override
    protected void onPause() {
        super.onPause();

    }

    @Override
    protected void onRestart() {
        super.onRestart();

    }



    public void checkans()
    {
        clear();

        switch(Ans.get(i)){

            case 0:
                l1.setBackgroundColor(Color.parseColor("#7CFC00"));
                break;

            case 1:
                l2.setBackgroundColor(Color.parseColor("#7CFC00"));

                break;
            case 2:
                l3.setBackgroundColor(Color.parseColor("#7CFC00"));

                break;
            case 3:
                l4.setBackgroundColor(Color.parseColor("#7CFC00"));
                break;

                       }
    }
    @Override
    public void onBackPressed(){
        new AlertDialog.Builder(test.this)
                .setTitle("Alert !!!")
                .setMessage("Do u want to exit ")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        endTest();
                    }

                }).setNegativeButton("No", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.cancel();
            }

        })
                .show();
    }

    public void done()
    {
        Ques.config(
                "MathJax.Hub.Config({\n"+
                        "  jax: [\"input/TeX\",\"output/HTML-CSS\"],\n" +

                        "  \"HTML-CSS\": {scale: 100, linebreaks: { automatic: true } },\n"+
                        "    displayAlign: \"left\""+
                        "});");


        OptD.config(
                "MathJax.Hub.Config({\n"+
                        "  \"HTML-CSS\": {scale: 100, linebreaks: { automatic: true } },\n"+
                        "  jax: [\"input/TeX\",\"output/HTML-CSS\"],\n" +
                        "});");

        OptA.config(
                "MathJax.Hub.Config({\n"+
                        "  \"HTML-CSS\": {scale: 100, linebreaks: { automatic: true } },\n"+
                        "  jax: [\"input/TeX\",\"output/HTML-CSS\"],\n" +
                        "});");

        OptB.config(
                "MathJax.Hub.Config({\n"+
                        "  \"HTML-CSS\": {scale: 100, linebreaks: { automatic: true } },\n"+
                        "  jax: [\"input/TeX\",\"output/HTML-CSS\"],\n" +
                        "});");
        OptC.config(
                "MathJax.Hub.Config({\n"+
                        "  \"HTML-CSS\": {scale: 100, linebreaks: { automatic: true } },\n"+
                        "  jax: [\"input/TeX\",\"output/HTML-CSS\"],\n" +
                        "});");

    }
}