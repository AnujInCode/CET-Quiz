package in.edu.mmit.quiz;

public class Bookmark {
    int Question_ID,SUBJECT_ID,CHAPTER_ID;
    Bookmark( int Question_ID,int SUBJECT_ID,int CHAPTER_ID)
    {
        this.Question_ID=Question_ID;
        this.CHAPTER_ID=CHAPTER_ID;
        this.SUBJECT_ID=SUBJECT_ID;
    }
}
