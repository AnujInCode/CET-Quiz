package in.edu.mmit.quiz;


import java.io.Serializable;

public class Question_info implements Serializable {
    int Question_ID,QUESTION_LEVEL,SUBJECT_ID,CHAPTER_ID,TOPIC_ID,ISQUESTIONASIMAGE,ISOPTIONASIMAGE,ISHINTASIMAGE,QUESTION_TYPE,ATTEMPTEDVALUE;
    String Que,OptA,OptB,OptC,OptD,Ans,Hint,QUESTIONIMAGEPATH, OPTIONIMAGEPATH,HINTIMAGEPATH, QUESTION_YEAR;
    Question_info( int Question_ID, int QUESTION_LEVEL, int SUBJECT_ID, int CHAPTER_ID, int TOPIC_ID, int ISQUESTIONASIMAGE, int ISOPTIONASIMAGE, int ISHINTASIMAGE, int QUESTION_TYPE, int ATTEMPTEDVALUE,String Que, String OptA, String OptB, String OptC, String OptD, String Ans, String Hint, String QUESTIONIMAGEPATH, String  OPTIONIMAGEPATH, String HINTIMAGEPATH, String  QUESTION_YEAR)
    {
        this.Question_ID=Question_ID;
        this.QUESTION_LEVEL=QUESTION_LEVEL;
        this.SUBJECT_ID=SUBJECT_ID;
        this.CHAPTER_ID=CHAPTER_ID;
        this.TOPIC_ID=TOPIC_ID;
        this.ISQUESTIONASIMAGE=ISQUESTIONASIMAGE;
        this.ISOPTIONASIMAGE=ISOPTIONASIMAGE;
        this.ISHINTASIMAGE=ISHINTASIMAGE;
        this.QUESTION_TYPE=QUESTION_TYPE;
        this.ATTEMPTEDVALUE=ATTEMPTEDVALUE;
        this.Que=Que;
        this.OptA=OptA;
        this.OptB=OptB;
        this.OptC=OptC;
        this.OptD=OptD;
        this.Ans=Ans;
        this.Hint=Hint;
        this.QUESTIONIMAGEPATH=QUESTIONIMAGEPATH;
        this.OPTIONIMAGEPATH=OPTIONIMAGEPATH;
        this.HINTIMAGEPATH=HINTIMAGEPATH;
        this.QUESTION_YEAR=QUESTION_YEAR;

    }

}
