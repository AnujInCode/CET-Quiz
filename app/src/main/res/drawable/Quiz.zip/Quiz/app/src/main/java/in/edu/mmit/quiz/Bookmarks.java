package in.edu.mmit.quiz;

import androidx.appcompat.app.AppCompatActivity;
import io.github.kexanie.library.MathView;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;

import java.util.ArrayList;

public class Bookmarks extends AppCompatActivity {
    int Math = 0;
    MathView A;
    LinearLayout ll;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bookmarks);
        Bookmark_Ret Bmark = new Bookmark_Ret(this);
        ArrayList<Bookmark> Res= Bmark.getAll(Math);
        ArrayList<Question_info> Ans=new ArrayList<>();
        RetrieveQuestion ret=new RetrieveQuestion(this);
        ScrollView scroll =new ScrollView(this);

        for(int i=0;i<Res.size();++i)
        {
            Ans.add(ret.Retrieve(Res.get(i).Question_ID));
        }
        ll=findViewById(R.id.ll11);
        scroll.addView(ll);

        Math+=Res.size();
        for(int i = 0; i < Res.size(); i++)
        {
            A = (MathView) findViewById(R.id.A);
            A.setText(Ans.get(i).Que);
            ll.addView(A);
        }

        scroll.addView(ll);
        this.setContentView(scroll);


    }
}
